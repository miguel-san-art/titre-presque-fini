from django.core.management.base import BaseCommand
from titles.models import ServiceType


class Command(BaseCommand):
    help = 'Charge les données initiales pour l\'application ART Telecom'

    def handle(self, *args, **options):
        self.stdout.write('Chargement des données initiales...')
        
        # Types de service par défaut
        service_types = [
            'Téléphonie Mobile',
            'Téléphonie Fixe',
            'Internet',
            'Télévision Radiodiffusion'
        ]
        
        for service_type_name in service_types:
            service_type, created = ServiceType.objects.get_or_create(
                name=service_type_name
            )
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'Type de service créé: {service_type_name}')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'Type de service existant: {service_type_name}')
                )
        
        self.stdout.write(
            self.style.SUCCESS('Chargement des données initiales terminé!')
        ) 