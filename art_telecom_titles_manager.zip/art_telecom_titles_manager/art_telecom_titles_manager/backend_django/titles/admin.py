from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from .models import ServiceType, Operator, TelecomTitle, ExcelUpload


@admin.register(ServiceType)
class ServiceTypeAdmin(admin.ModelAdmin):
    list_display = ['name', 'description', 'created_at']
    search_fields = ['name', 'description']
    list_filter = ['created_at']
    ordering = ['name']


@admin.register(Operator)
class OperatorAdmin(admin.ModelAdmin):
    list_display = ['name', 'region', 'contact_email', 'contact_phone', 'created_at']
    search_fields = ['name', 'region', 'contact_email']
    list_filter = ['region', 'created_at']
    ordering = ['name']


@admin.register(TelecomTitle)
class TelecomTitleAdmin(admin.ModelAdmin):
    list_display = [
        'title_number', 
        'operator', 
        'service_type', 
        'status', 
        'issue_date', 
        'expiry_date', 
        'revenue',
        'is_expired_display',
        'is_expiring_soon_display'
    ]
    list_filter = [
        'status', 
        'service_type', 
        'operator', 
        'region', 
        'issue_date', 
        'expiry_date',
        'created_at'
    ]
    search_fields = [
        'title_number', 
        'operator__name', 
        'service_type__name', 
        'region',
        'frequency_range'
    ]
    date_hierarchy = 'created_at'
    ordering = ['-created_at']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('Informations de base', {
            'fields': ('title_number', 'operator', 'service_type', 'status')
        }),
        ('Détails techniques', {
            'fields': ('frequency_range', 'region')
        }),
        ('Dates', {
            'fields': ('issue_date', 'expiry_date')
        }),
        ('Financier', {
            'fields': ('revenue',)
        }),
        ('Métadonnées', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def is_expired_display(self, obj):
        if obj.is_expired:
            return format_html('<span style="color: red;">⚠️ Expiré</span>')
        return format_html('<span style="color: green;">✅ Actif</span>')
    is_expired_display.short_description = 'Statut d\'expiration'

    def is_expiring_soon_display(self, obj):
        if obj.is_expiring_soon and not obj.is_expired:
            return format_html('<span style="color: orange;">⚠️ Expire bientôt</span>')
        return '-'
    is_expiring_soon_display.short_description = 'Expiration proche'

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('operator', 'service_type')


@admin.register(ExcelUpload)
class ExcelUploadAdmin(admin.ModelAdmin):
    list_display = [
        'id', 
        'file_name', 
        'uploaded_at', 
        'processed', 
        'records_processed',
        'status_display'
    ]
    list_filter = ['processed', 'uploaded_at']
    readonly_fields = ['uploaded_at', 'processed', 'records_processed', 'error_message']
    ordering = ['-uploaded_at']

    def file_name(self, obj):
        return obj.file.name.split('/')[-1]
    file_name.short_description = 'Nom du fichier'

    def status_display(self, obj):
        if obj.processed:
            if obj.error_message:
                return format_html('<span style="color: red;">❌ Erreur</span>')
            return format_html('<span style="color: green;">✅ Traité</span>')
        return format_html('<span style="color: orange;">⏳ En attente</span>')
    status_display.short_description = 'Statut' 