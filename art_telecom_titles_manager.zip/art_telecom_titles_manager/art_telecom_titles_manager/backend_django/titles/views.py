from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Count, Sum, Q
from django.utils import timezone
from datetime import timedelta
import pandas as pd
import openpyxl
from io import BytesIO

from .models import ServiceType, Operator, TelecomTitle, ExcelUpload
from .serializers import (
    ServiceTypeSerializer, OperatorSerializer, TelecomTitleSerializer,
    TelecomTitleListSerializer, ExcelUploadSerializer, StatisticsSerializer
)


class ServiceTypeViewSet(viewsets.ModelViewSet):
    queryset = ServiceType.objects.all()
    serializer_class = ServiceTypeSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'description']
    ordering_fields = ['name', 'created_at']
    ordering = ['name']


class OperatorViewSet(viewsets.ModelViewSet):
    queryset = Operator.objects.all()
    serializer_class = OperatorSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'region', 'contact_email']
    ordering_fields = ['name', 'region', 'created_at']
    ordering = ['name']


class TelecomTitleViewSet(viewsets.ModelViewSet):
    queryset = TelecomTitle.objects.select_related('operator', 'service_type').all()
    serializer_class = TelecomTitleSerializer
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['status', 'service_type', 'operator', 'region']
    search_fields = ['title_number', 'operator__name', 'service_type__name', 'region']
    ordering_fields = ['title_number', 'issue_date', 'expiry_date', 'revenue', 'created_at']
    ordering = ['-created_at']

    def get_serializer_class(self):
        if self.action == 'list':
            return TelecomTitleListSerializer
        return TelecomTitleSerializer

    @action(detail=False, methods=['get'])
    def statistics(self, request):
        """Récupère les statistiques globales"""
        queryset = self.get_queryset()
        
        # Statistiques de base
        total_titles = queryset.count()
        active_titles = queryset.filter(status='actif').count()
        expiring_soon = queryset.filter(
            status='actif',
            expiry_date__lte=timezone.now().date() + timedelta(days=30)
        ).count()
        total_revenue = queryset.filter(status='actif').aggregate(
            total=Sum('revenue')
        )['total'] or 0

        # Statistiques par opérateur
        titles_by_operator = queryset.values('operator__name').annotate(
            count=Count('id')
        ).order_by('-count')

        # Statistiques par type de service
        titles_by_service_type = queryset.values('service_type__name').annotate(
            count=Count('id')
        ).order_by('-count')

        # Statistiques par région
        titles_by_region = queryset.values('region').annotate(
            count=Count('id')
        ).filter(region__isnull=False).exclude(region='').order_by('-count')

        data = {
            'total_titles': total_titles,
            'active_titles': active_titles,
            'expiring_soon': expiring_soon,
            'total_revenue': total_revenue,
            'titles_by_operator': list(titles_by_operator),
            'titles_by_service_type': list(titles_by_service_type),
            'titles_by_region': list(titles_by_region),
        }

        serializer = StatisticsSerializer(data)
        return Response(serializer.data)

    @action(detail=False, methods=['post'])
    def upload_excel(self, request):
        """Upload et traitement de fichiers Excel"""
        if 'file' not in request.FILES:
            return Response(
                {'error': 'Aucun fichier fourni'}, 
                status=status.HTTP_400_BAD_REQUEST
            )

        file = request.FILES['file']
        
        # Validation du type de fichier
        allowed_extensions = ['.xlsx', '.xls', '.csv']
        file_extension = file.name.lower()
        if not any(file_extension.endswith(ext) for ext in allowed_extensions):
            return Response(
                {'error': 'Type de fichier non supporté. Utilisez .xlsx, .xls ou .csv'},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Créer l'enregistrement d'upload
        upload_record = ExcelUpload.objects.create(file=file)
        
        try:
            # Traiter le fichier Excel
            processed_data = self._process_excel_file(file)
            
            # Mettre à jour l'enregistrement
            upload_record.processed = True
            upload_record.records_processed = len(processed_data)
            upload_record.save()
            
            return Response({
                'message': 'Fichier traité avec succès',
                'records_processed': len(processed_data),
                'data': processed_data
            })
            
        except Exception as e:
            # Enregistrer l'erreur
            upload_record.processed = True
            upload_record.error_message = str(e)
            upload_record.save()
            
            return Response(
                {'error': f'Erreur lors du traitement: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def _process_excel_file(self, file):
        """Traite le fichier Excel et retourne les données traitées"""
        try:
            # Lire le fichier Excel
            if file.name.endswith('.csv'):
                df = pd.read_csv(file)
            else:
                df = pd.read_excel(file)
            
            processed_data = []
            
            for index, row in df.iterrows():
                try:
                    # Mapping des colonnes
                    operator_name = self._get_column_value(row, ['Opérateur', 'OPERATEUR', 'operator'])
                    service_type_name = self._get_column_value(row, ['Type de Service', 'TYPE_SERVICE', 'service_type'])
                    title_number = self._get_column_value(row, ['Numéro de Titre', 'NUMERO_TITRE', 'title_number'])
                    frequency_range = self._get_column_value(row, ['Plage de Fréquence', 'FREQUENCE', 'frequency'])
                    region = self._get_column_value(row, ['Région', 'REGION', 'region'])
                    issue_date = self._parse_date(self._get_column_value(row, ['Date d\'Émission', 'DATE_EMISSION', 'issue_date']))
                    expiry_date = self._parse_date(self._get_column_value(row, ['Date d\'Expiration', 'DATE_EXPIRATION', 'expiry_date']))
                    revenue = self._parse_revenue(self._get_column_value(row, ['Revenus', 'REVENUS', 'revenue']))
                    
                    # Validation des données obligatoires
                    if not all([operator_name, service_type_name, title_number]):
                        continue
                    
                    # Créer ou récupérer l'opérateur
                    operator, _ = Operator.objects.get_or_create(name=operator_name)
                    
                    # Créer ou récupérer le type de service
                    service_type, _ = ServiceType.objects.get_or_create(name=service_type_name)
                    
                    # Créer ou mettre à jour le titre
                    title, created = TelecomTitle.objects.update_or_create(
                        title_number=title_number,
                        defaults={
                            'operator': operator,
                            'service_type': service_type,
                            'frequency_range': frequency_range or '',
                            'region': region or '',
                            'issue_date': issue_date,
                            'expiry_date': expiry_date,
                            'revenue': revenue,
                        }
                    )
                    
                    processed_data.append({
                        'id': title.id,
                        'title_number': title.title_number,
                        'operator': operator.name,
                        'service_type': service_type.name,
                        'created': created
                    })
                    
                except Exception as e:
                    print(f"Erreur lors du traitement de la ligne {index + 1}: {e}")
                    continue
            
            return processed_data
            
        except Exception as e:
            raise Exception(f"Erreur lors de la lecture du fichier: {str(e)}")

    def _get_column_value(self, row, possible_names):
        """Récupère la valeur d'une colonne en essayant différents noms possibles"""
        for name in possible_names:
            if name in row:
                value = row[name]
                if pd.isna(value):
                    return ''
                return str(value).strip()
        return ''

    def _parse_date(self, date_string):
        """Parse une date depuis une chaîne"""
        if not date_string:
            return timezone.now().date()
        
        try:
            # Essayer différents formats de date
            import datetime
            for fmt in ['%Y-%m-%d', '%d/%m/%Y', '%d-%m-%Y', '%Y/%m/%d']:
                try:
                    return datetime.datetime.strptime(date_string, fmt).date()
                except ValueError:
                    continue
            
            # Si aucun format ne fonctionne, retourner la date actuelle
            return timezone.now().date()
        except:
            return timezone.now().date()

    def _parse_revenue(self, revenue_string):
        """Parse un montant depuis une chaîne"""
        if not revenue_string:
            return 0
        
        try:
            # Nettoyer la chaîne (supprimer les espaces, virgules, etc.)
            cleaned = str(revenue_string).replace(',', '').replace(' ', '').replace('XAF', '').replace('FCFA', '')
            return float(cleaned)
        except:
            return 0


class ExcelUploadViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = ExcelUpload.objects.all()
    serializer_class = ExcelUploadSerializer
    ordering = ['-uploaded_at'] 