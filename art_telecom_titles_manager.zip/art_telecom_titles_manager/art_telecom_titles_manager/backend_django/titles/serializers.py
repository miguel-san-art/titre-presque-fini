from rest_framework import serializers
from .models import ServiceType, Operator, TelecomTitle, ExcelUpload


class ServiceTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceType
        fields = '__all__'


class OperatorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Operator
        fields = '__all__'


class TelecomTitleSerializer(serializers.ModelSerializer):
    operator_name = serializers.CharField(source='operator.name', read_only=True)
    service_type_name = serializers.CharField(source='service_type.name', read_only=True)
    is_expired = serializers.BooleanField(read_only=True)
    is_expiring_soon = serializers.BooleanField(read_only=True)

    class Meta:
        model = TelecomTitle
        fields = [
            'id', 'operator', 'operator_name', 'service_type', 'service_type_name',
            'title_number', 'frequency_range', 'region', 'issue_date', 'expiry_date',
            'status', 'revenue', 'created_at', 'updated_at', 'is_expired', 'is_expiring_soon'
        ]
        read_only_fields = ['created_at', 'updated_at']


class TelecomTitleListSerializer(serializers.ModelSerializer):
    operator_name = serializers.CharField(source='operator.name', read_only=True)
    service_type_name = serializers.CharField(source='service_type.name', read_only=True)

    class Meta:
        model = TelecomTitle
        fields = [
            'id', 'operator_name', 'service_type_name', 'title_number',
            'status', 'revenue', 'region', 'expiry_date'
        ]


class ExcelUploadSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExcelUpload
        fields = ['id', 'file', 'uploaded_at', 'processed', 'records_processed', 'error_message']
        read_only_fields = ['uploaded_at', 'processed', 'records_processed', 'error_message']


class StatisticsSerializer(serializers.Serializer):
    total_titles = serializers.IntegerField()
    active_titles = serializers.IntegerField()
    expiring_soon = serializers.IntegerField()
    total_revenue = serializers.DecimalField(max_digits=15, decimal_places=2)
    titles_by_operator = serializers.ListField()
    titles_by_service_type = serializers.ListField()
    titles_by_region = serializers.ListField() 