from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'service-types', views.ServiceTypeViewSet)
router.register(r'operators', views.OperatorViewSet)
router.register(r'titles', views.TelecomTitleViewSet)
router.register(r'uploads', views.ExcelUploadViewSet)

urlpatterns = [
    path('', include(router.urls)),
] 