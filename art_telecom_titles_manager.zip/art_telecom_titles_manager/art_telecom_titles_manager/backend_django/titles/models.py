from django.db import models
from django.core.validators import MinValueValidator
from django.utils import timezone


class ServiceType(models.Model):
    """Modèle pour les types de service"""
    name = models.CharField(max_length=100, unique=True, verbose_name="Nom du type de service")
    description = models.TextField(blank=True, verbose_name="Description")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Date de création")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Date de mise à jour")

    class Meta:
        verbose_name = "Type de service"
        verbose_name_plural = "Types de service"
        ordering = ['name']

    def __str__(self):
        return self.name


class Operator(models.Model):
    """Modèle pour les opérateurs"""
    name = models.CharField(max_length=200, unique=True, verbose_name="Nom de l'opérateur")
    region = models.CharField(max_length=100, blank=True, verbose_name="Région")
    contact_email = models.EmailField(blank=True, verbose_name="Email de contact")
    contact_phone = models.CharField(max_length=20, blank=True, verbose_name="Téléphone de contact")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Date de création")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Date de mise à jour")

    class Meta:
        verbose_name = "Opérateur"
        verbose_name_plural = "Opérateurs"
        ordering = ['name']

    def __str__(self):
        return self.name


class TelecomTitle(models.Model):
    """Modèle pour les titres de télécommunications"""
    STATUS_CHOICES = [
        ('actif', 'Actif'),
        ('expiré', 'Expiré'),
        ('suspendu', 'Suspendu'),
        ('révoqué', 'Révoqué'),
    ]

    operator = models.ForeignKey(
        Operator, 
        on_delete=models.CASCADE, 
        verbose_name="Opérateur",
        related_name='titles'
    )
    service_type = models.ForeignKey(
        ServiceType, 
        on_delete=models.CASCADE, 
        verbose_name="Type de service",
        related_name='titles'
    )
    title_number = models.CharField(
        max_length=100, 
        unique=True, 
        verbose_name="Numéro de titre"
    )
    frequency_range = models.CharField(
        max_length=200, 
        blank=True, 
        verbose_name="Plage de fréquence"
    )
    region = models.CharField(
        max_length=100, 
        blank=True, 
        verbose_name="Région"
    )
    issue_date = models.DateField(
        verbose_name="Date d'émission"
    )
    expiry_date = models.DateField(
        verbose_name="Date d'expiration"
    )
    status = models.CharField(
        max_length=20, 
        choices=STATUS_CHOICES, 
        default='actif',
        verbose_name="Statut"
    )
    revenue = models.DecimalField(
        max_digits=15, 
        decimal_places=2, 
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name="Revenus (XAF)"
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Date de création")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Date de mise à jour")

    class Meta:
        verbose_name = "Titre de télécommunication"
        verbose_name_plural = "Titres de télécommunications"
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['operator', 'service_type']),
            models.Index(fields=['status', 'expiry_date']),
            models.Index(fields=['title_number']),
        ]

    def __str__(self):
        return f"{self.title_number} - {self.operator.name}"

    @property
    def is_expired(self):
        """Vérifie si le titre est expiré"""
        return self.expiry_date < timezone.now().date()

    @property
    def is_expiring_soon(self):
        """Vérifie si le titre expire dans les 30 prochains jours"""
        from datetime import timedelta
        return (self.expiry_date - timezone.now().date()) <= timedelta(days=30)

    def save(self, *args, **kwargs):
        # Mettre à jour automatiquement le statut si expiré
        if self.is_expired and self.status == 'actif':
            self.status = 'expiré'
        super().save(*args, **kwargs)


class ExcelUpload(models.Model):
    """Modèle pour tracer les uploads Excel"""
    file = models.FileField(upload_to='excel_uploads/', verbose_name="Fichier Excel")
    uploaded_at = models.DateTimeField(auto_now_add=True, verbose_name="Date d'upload")
    processed = models.BooleanField(default=False, verbose_name="Traité")
    records_processed = models.IntegerField(default=0, verbose_name="Enregistrements traités")
    error_message = models.TextField(blank=True, verbose_name="Message d'erreur")

    class Meta:
        verbose_name = "Upload Excel"
        verbose_name_plural = "Uploads Excel"
        ordering = ['-uploaded_at']

    def __str__(self):
        return f"Upload {self.id} - {self.file.name}" 