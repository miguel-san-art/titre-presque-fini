#!/bin/bash

echo "========================================"
echo "    ART Telecom Django Backend - Demarrage"
echo "========================================"
echo

# Vérifier si Python est installé
if ! command -v python3 &> /dev/null; then
    echo "ERREUR: Python 3 n'est pas installé ou n'est pas dans le PATH"
    echo "Veuillez installer Python 3 depuis https://python.org/"
    exit 1
fi

echo "Python detecte:"
python3 --version
echo

# Vérifier si l'environnement virtuel existe
if [ ! -d "venv" ]; then
    echo "Creation de l'environnement virtuel..."
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "ERREUR: Echec de la creation de l'environnement virtuel"
        exit 1
    fi
    echo
fi

# Activer l'environnement virtuel
echo "Activation de l'environnement virtuel..."
source venv/bin/activate
if [ $? -ne 0 ]; then
    echo "ERREUR: Echec de l'activation de l'environnement virtuel"
    exit 1
fi

# Vérifier si les dépendances sont installées
if [ ! -d "venv/lib/python*/site-packages/django" ]; then
    echo "Installation des dependances..."
    pip install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "ERREUR: Echec de l'installation des dependances"
        exit 1
    fi
    echo
fi

# Vérifier si les migrations ont été effectuées
if [ ! -f "db.sqlite3" ]; then
    echo "Application des migrations..."
    python manage.py makemigrations
    python manage.py migrate
    if [ $? -ne 0 ]; then
        echo "ERREUR: Echec des migrations"
        exit 1
    fi
    echo
    
    echo "Chargement des donnees initiales..."
    python manage.py load_initial_data
    echo
fi

echo "Demarrage du serveur Django..."
echo "Le serveur sera accessible sur http://localhost:8000"
echo "L'interface d'administration sera accessible sur http://localhost:8000/admin/"
echo
echo "Appuyez sur Ctrl+C pour arreter le serveur"
echo

python manage.py runserver 