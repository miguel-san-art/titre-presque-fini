# Backend Django - ART Telecom Titles Manager

Ce backend Django permet d'intégrer et de gérer les fichiers Excel contenant les données des titres de télécommunications de l'ART Cameroun.

## 🚀 Installation

### Prérequis
- Python 3.8 ou supérieur
- Django 4.2+
- pip

### Installation des dépendances

```bash
cd backend_django
pip install -r requirements.txt
```

## 🏃‍♂️ Démarrage

### 1. Migrations de la base de données
```bash
python manage.py makemigrations
python manage.py migrate
```

### 2. Création d'un superutilisateur
```bash
python manage.py createsuperuser
```

### 3. Chargement des données initiales
```bash
python manage.py load_initial_data
```

### 4. Démarrage du serveur
```bash
python manage.py runserver
```

Le serveur sera accessible sur `http://localhost:8000`

## 📊 Structure de la base de données

### Modèles principaux

#### `ServiceType`
- `name` : Nom du type de service (unique)
- `description` : Description optionnelle
- `created_at` : Date de création
- `updated_at` : Date de mise à jour

#### `Operator`
- `name` : Nom de l'opérateur (unique)
- `region` : Région géographique
- `contact_email` : Email de contact
- `contact_phone` : Téléphone de contact
- `created_at` : Date de création
- `updated_at` : Date de mise à jour

#### `TelecomTitle`
- `operator` : Référence vers l'opérateur (ForeignKey)
- `service_type` : Référence vers le type de service (ForeignKey)
- `title_number` : Numéro unique du titre
- `frequency_range` : Plage de fréquence utilisée
- `region` : Région géographique
- `issue_date` : Date d'émission
- `expiry_date` : Date d'expiration
- `status` : Statut (actif, expiré, suspendu, révoqué)
- `revenue` : Revenus en XAF
- `created_at` : Date de création
- `updated_at` : Date de mise à jour

#### `ExcelUpload`
- `file` : Fichier Excel uploadé
- `uploaded_at` : Date d'upload
- `processed` : Statut de traitement
- `records_processed` : Nombre d'enregistrements traités
- `error_message` : Message d'erreur si échec

## 🔌 API Endpoints

### Types de service
```
GET /api/service-types/ - Liste des types de service
POST /api/service-types/ - Créer un type de service
GET /api/service-types/{id}/ - Détails d'un type de service
PUT /api/service-types/{id}/ - Mettre à jour un type de service
DELETE /api/service-types/{id}/ - Supprimer un type de service
```

### Opérateurs
```
GET /api/operators/ - Liste des opérateurs
POST /api/operators/ - Créer un opérateur
GET /api/operators/{id}/ - Détails d'un opérateur
PUT /api/operators/{id}/ - Mettre à jour un opérateur
DELETE /api/operators/{id}/ - Supprimer un opérateur
```

### Titres de télécommunications
```
GET /api/titles/ - Liste des titres
POST /api/titles/ - Créer un titre
GET /api/titles/{id}/ - Détails d'un titre
PUT /api/titles/{id}/ - Mettre à jour un titre
DELETE /api/titles/{id}/ - Supprimer un titre
GET /api/titles/statistics/ - Statistiques globales
POST /api/titles/upload_excel/ - Upload de fichier Excel
```

### Uploads Excel
```
GET /api/uploads/ - Liste des uploads
GET /api/uploads/{id}/ - Détails d'un upload
```

## 📁 Structure des fichiers Excel

Le backend accepte les fichiers Excel avec les colonnes suivantes :

### Colonnes obligatoires
- **Opérateur** : Nom de l'opérateur
- **Type de Service** : Type de service (sera automatiquement mappé)
- **Numéro de Titre** : Numéro unique du titre

### Colonnes optionnelles
- **Plage de Fréquence** : Plage de fréquence utilisée
- **Région** : Région géographique
- **Date d'Émission** : Date d'émission du titre (format YYYY-MM-DD)
- **Date d'Expiration** : Date d'expiration du titre (format YYYY-MM-DD)
- **Revenus** : Montant des revenus (nombre)

### Mapping automatique des types de service

Le backend mappe automatiquement les types de service suivants :

| Valeur dans Excel | Type mappé |
|-------------------|------------|
| mobile, téléphonie mobile | Téléphonie Mobile |
| fixe, téléphonie fixe | Téléphonie Fixe |
| internet | Internet |
| tv, télévision, radiodiffusion, radio | Télévision Radiodiffusion |

## 🔧 Configuration

Le fichier `settings.py` contient toutes les configurations du projet :

```python
# Configuration de base
DEBUG = True
ALLOWED_HOSTS = ['localhost', '127.0.0.1']

# Base de données
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# REST Framework
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.BasicAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticatedOrReadOnly',
    ],
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 50,
}
```

## 🛡️ Sécurité

- **CORS** : Configuration des origines autorisées
- **Validation des fichiers** : Vérification des types et tailles de fichiers
- **Authentification** : Interface d'administration Django
- **Permissions** : Gestion des permissions par défaut

## 📝 Logs

Les logs sont configurés dans `settings.py` et incluent :
- Erreurs de traitement des fichiers Excel
- Erreurs de base de données
- Requêtes API
- Informations de démarrage

## 🚨 Gestion des erreurs

Le backend gère automatiquement :
- Fichiers Excel malformés
- Données manquantes ou invalides
- Erreurs de base de données
- Fichiers trop volumineux
- Types de fichiers non supportés

## 🔄 Intégration avec le frontend

Le frontend peut utiliser les endpoints API pour :
- Uploader des fichiers Excel
- Récupérer les données en temps réel
- Actualiser les statistiques
- Exporter les données

## 📊 Interface d'administration

L'interface d'administration Django est accessible sur `/admin/` et permet de :
- Gérer les types de service
- Gérer les opérateurs
- Gérer les titres de télécommunications
- Voir les uploads Excel
- Consulter les statistiques

## 🚀 Commandes de gestion

### Charger les données initiales
```bash
python manage.py load_initial_data
```

### Créer un superutilisateur
```bash
python manage.py createsuperuser
```

### Collecter les fichiers statiques
```bash
python manage.py collectstatic
```

## 📞 Support

Pour toute question ou problème, consultez la documentation ou contactez l'équipe de développement. 