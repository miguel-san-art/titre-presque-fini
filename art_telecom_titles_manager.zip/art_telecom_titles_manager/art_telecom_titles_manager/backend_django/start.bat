@echo off
echo ========================================
echo    ART Telecom Django Backend - Demarrage
echo ========================================
echo.

REM Vérifier si Python est installé
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERREUR: Python n'est pas installé ou n'est pas dans le PATH
    echo Veuillez installer Python depuis https://python.org/
    pause
    exit /b 1
)

echo Python detecte: 
python --version
echo.

REM Vérifier si les dépendances sont installées
if not exist "venv" (
    echo Creation de l'environnement virtuel...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo ERREUR: Echec de la creation de l'environnement virtuel
        pause
        exit /b 1
    )
    echo.
)

REM Activer l'environnement virtuel
echo Activation de l'environnement virtuel...
call venv\Scripts\activate.bat
if %errorlevel% neq 0 (
    echo ERREUR: Echec de l'activation de l'environnement virtuel
    pause
    exit /b 1
)

REM Vérifier si les dépendances sont installées
if not exist "venv\Lib\site-packages\django" (
    echo Installation des dependances...
    pip install -r requirements.txt
    if %errorlevel% neq 0 (
        echo ERREUR: Echec de l'installation des dependances
        pause
        exit /b 1
    )
    echo.
)

REM Vérifier si les migrations ont été effectuées
if not exist "db.sqlite3" (
    echo Application des migrations...
    python manage.py makemigrations
    python manage.py migrate
    if %errorlevel% neq 0 (
        echo ERREUR: Echec des migrations
        pause
        exit /b 1
    )
    echo.
    
    echo Chargement des donnees initiales...
    python manage.py load_initial_data
    echo.
)

echo Demarrage du serveur Django...
echo Le serveur sera accessible sur http://localhost:8000
echo L'interface d'administration sera accessible sur http://localhost:8000/admin/
echo.
echo Appuyez sur Ctrl+C pour arreter le serveur
echo.

python manage.py runserver 